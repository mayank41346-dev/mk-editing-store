<?php require "config.php"; ?><!doctype html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Customer Support - MK Editing Store</title>
<style>
body{margin:0;background:#050509;color:#fff;font-family:Arial;min-height:100vh;display:grid;place-items:center}
.box{width:min(92%,520px);background:#101017;border:1px solid #272731;border-radius:20px;padding:30px;text-align:center}
h1{color:#00eaff} a{color:#00eaff;text-decoration:none} .support-name{font-size:22px;font-weight:bold}
</style></head><body><main class="box"><h1>Customer Support</h1><p class="support-name">Mayank Editor</p>
<p><a href="mailto:mayankeditor91@gmail.com">📧 mayankeditor91@gmail.com</a></p>
<p><a href="https://instagram.com/royal_editor_mayank" target="_blank" rel="noopener">📸 @royal_editor_mayank</a></p>
<p><a href="index.php">← Back to Store</a></p></main></body></html>