<?php
require "config.php";
$id=intval($_GET["id"]??0);
$p=null;
foreach(read_json("products.json") as $x) if(intval($x["id"])===$id) $p=$x;
if(!$p) die("Product not found.");
$e=""; $coupon_msg=""; $applied=null;
$base=(float)$p["price"];
function find_coupon($code){
    $code=strtoupper(trim($code));
    foreach(read_json("coupons.json") as $c){
        if(strtoupper($c["code"]??"")===$code) return $c;
    }
    return null;
}
function coupon_discount($coupon,$base){
    if(!$coupon || empty($coupon["active"])) return 0;
    $min=(float)($coupon["min_order"]??0);
    if($min>0 && $base<$min) return 0;
    $used=(int)($coupon["used_count"]??0); $max=(int)($coupon["max_uses"]??0);
    if($max>0 && $used>=$max) return 0;
    $value=(float)($coupon["value"]??0);
    $d=(($coupon["type"]??"fixed")==="percent") ? $base*$value/100 : $value;
    return min(max($d,0),$base);
}
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $name=trim($_POST["name"]??""); $email=trim($_POST["email"]??""); $utr=trim($_POST["utr"]??""); $coupon_code=strtoupper(trim($_POST["coupon_code"]??""));
    $applied=$coupon_code!=="" ? find_coupon($coupon_code) : null;
    $discount=coupon_discount($applied,$base);
    if($coupon_code!=="" && $discount<=0) {
        $min=(float)($applied["min_order"]??0);
        $e=($applied && $min>0 && $base<$min) ? "This coupon requires a minimum order of ₹".number_format($min,2)."." : "Invalid, inactive, or expired coupon code.";
    }
    elseif($name===""||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($utr)<6) $e="Enter valid details.";
    elseif(empty($_FILES["screenshot"]["tmp_name"])) $e="Upload payment screenshot.";
    else{
        $mime=mime_content_type($_FILES["screenshot"]["tmp_name"]);
        if(!in_array($mime,["image/jpeg","image/png","image/webp"],true)) $e="Screenshot must be JPG, PNG or WEBP.";
        elseif($_FILES["screenshot"]["size"]>5*1024*1024) $e="Screenshot must be under 5MB.";
        else{
            $ext=strtolower(pathinfo($_FILES["screenshot"]["name"],PATHINFO_EXTENSION));
            $fn=bin2hex(random_bytes(16)).".".$ext; $rel="uploads/payments/".$fn;
            if(move_uploaded_file($_FILES["screenshot"]["tmp_name"],__DIR__."/".$rel)){
                $os=read_json("orders.json"); $oid=1; foreach($os as $o) $oid=max($oid,intval($o["id"])+1);
                $final=max(0,$base-$discount);
                $os[]=["id"=>$oid,"product_id"=>$id,"name"=>$name,"email"=>$email,"utr"=>$utr,"screenshot"=>$rel,"amount"=>number_format($final,2,'.',''),"original_amount"=>number_format($base,2,'.',''),"discount"=>number_format($discount,2,'.',''),"coupon_code"=>$coupon_code,"status"=>"pending","created_at"=>date("Y-m-d H:i:s")];
                write_json("orders.json",$os);
                if($applied){
                    $all=read_json("coupons.json");
                    foreach($all as &$c) if(strtoupper($c["code"]??"")===strtoupper($applied["code"])) $c["used_count"]=(int)($c["used_count"]??0)+1;
                    unset($c); write_json("coupons.json",$all);
                }
                header("Location: order-status.php?id=".$oid); exit;
            }
        }
    }
}
$initial_coupon="";
?>
<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Payment</title><style>*{box-sizing:border-box}body{margin:0;background:#050509;color:white;font-family:Arial;padding:20px}.wrap{max-width:650px;margin:auto}.box{background:#101017;border:1px solid #292933;border-radius:18px;padding:20px}.qr{width:min(330px,100%);display:block;margin:10px auto}.upi{text-align:center;color:#00eaff}input{width:100%;padding:13px;margin:7px 0 12px;background:#07070b;color:white;border:1px solid #333;border-radius:9px}button{width:100%;padding:14px;background:#00eaff;border:0;border-radius:9px;font-weight:bold;cursor:pointer}.coupon-row{display:flex;gap:8px}.coupon-row input{margin:0}.coupon-row button{width:130px}.summary{background:#07111d;border:1px solid #17334b;border-radius:12px;padding:14px;margin:14px 0}.summary div{display:flex;justify-content:space-between;margin:6px 0}.total{font-size:20px;color:#00eaff;font-weight:bold}.msg{color:#65ffae;margin:8px 0}.e{background:#351010;color:#ff7777;padding:10px;border-radius:8px;margin-bottom:12px}</style><body><div class=wrap><a style=color:#00eaff href=index.php>← Store</a><div class=box><h1><?=h($p["name"])?></h1><div class=summary><div><span>Original price</span><b>₹<span id="base"><?=number_format($base,2)?></span></b></div><div><span>Discount</span><b>− ₹<span id="discount">0.00</span></b></div><div class=total><span>Pay</span><span>₹<span id="total"><?=number_format($base,2)?></span></span></div></div><img id="upiQr" class="qr" src="assets/payment-qr.jpg" alt="UPI Payment QR"><p class=upi>UPI ID: <?=h($UPI_ID)?></p><p id="qrAmount" class="upi" style="font-size:14px">Scan to pay ₹<?=number_format($base,2)?></p><?php if($e):?><div class=e><?=h($e)?></div><?php endif;?><form method=post enctype=multipart/form-data><label>Coupon code</label><div class=coupon-row><input id=coupon_code name=coupon_code value="<?=h($_POST["coupon_code"]??"")?>" placeholder="Example: SAVE10"><button type=button onclick="checkCoupon()">APPLY</button></div><div id=couponMsg class=msg></div><input name=name placeholder="Your name" required><input type=email name=email placeholder="Email" required><input name=utr placeholder="UPI UTR / Transaction ID" required><input type=file name=screenshot accept="image/jpeg,image/png,image/webp" required><button type=submit>SUBMIT PAYMENT</button></form></div></div><script>
const base=<?=json_encode($base)?>;
let coupons=<?=json_encode(read_json("coupons.json"))?>;
function updateQr(amount){
  amount=Math.max(0, Number(amount)||0).toFixed(2);
  const upi=<?=json_encode($UPI_ID)?>;
  const name=<?=json_encode($STORE_NAME)?>;
  const uri='upi://pay?pa='+encodeURIComponent(upi)+'&pn='+encodeURIComponent(name)+'&am='+encodeURIComponent(amount)+'&cu=INR';
  const qr='https://quickchart.io/qr?size=330&margin=2&text='+encodeURIComponent(uri);
  document.getElementById('upiQr').src=qr;
  document.getElementById('qrAmount').textContent='Scan to pay ₹'+amount;
}
function checkCoupon(){const code=document.getElementById('coupon_code').value.trim().toUpperCase();const msg=document.getElementById('couponMsg');let c=coupons.find(x=>(x.code||'').toUpperCase()===code);let d=0;if(c&&c.active&&(!c.max_uses||Number(c.used_count||0)<Number(c.max_uses||0))&&(!c.min_order||base>=Number(c.min_order))){d=c.type==='percent'?base*Number(c.value)/100:Number(c.value);d=Math.min(Math.max(d,0),base);msg.textContent='Coupon applied: '+(c.type==='percent'?c.value+'% OFF':'₹'+Number(c.value).toFixed(2)+' OFF');}else if(code){msg.textContent=(c&&c.min_order&&base<Number(c.min_order))?'Minimum order ₹'+Number(c.min_order).toFixed(2)+' required.':'Invalid or expired coupon.';}else{msg.textContent='';}document.getElementById('discount').textContent=d.toFixed(2);document.getElementById('total').textContent=(base-d).toFixed(2);updateQr(base-d);}
updateQr(base);
</script></body></html>
