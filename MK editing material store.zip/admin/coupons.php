<?php
require "../config.php";
admin_required();
$e="";
$ok="";
$coupons=read_json("coupons.json");
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $action=$_POST["action"]??"create";
    if($action==="delete"){
        $code=strtoupper(trim($_POST["code"]??""));
        $coupons=array_values(array_filter($coupons,fn($c)=>strtoupper($c["code"]??"")!==$code));
        write_json("coupons.json",$coupons);
        header("Location: coupons.php"); exit;
    }
    if($action==="toggle"){
        $code=strtoupper(trim($_POST["code"]??""));
        foreach($coupons as &$c) if(strtoupper($c["code"]??"")===$code) $c["active"]=!($c["active"]??false);
        unset($c); write_json("coupons.json",$coupons); header("Location: coupons.php"); exit;
    }
    $code=strtoupper(trim($_POST["code"]??""));
    $type=$_POST["type"]??"fixed";
    $value=(float)($_POST["value"]??0);
    $max=(int)($_POST["max_uses"]??0);
    $min=(float)($_POST["min_order"]??0);
    if(!preg_match('/^[A-Z0-9_-]{3,30}$/',$code)) $e="Coupon code: 3-30 letters/numbers only (A-Z, 0-9, _ or -).";
    elseif(!in_array($type,["fixed","percent"],true)) $e="Invalid discount type.";
    elseif($value<=0 || ($type==="percent" && $value>100)) $e="Enter a valid discount value.";
    elseif($max<0) $e="Max uses cannot be negative.";
    elseif($min<0) $e="Minimum order cannot be negative.";
    else{
        foreach($coupons as $c) if(strtoupper($c["code"]??"")===$code) $e="This coupon code already exists.";
        if($e===""){
            $coupons[]=["code"=>$code,"type"=>$type,"value"=>$value,"max_uses"=>$max,"min_order"=>$min,"used_count"=>0,"active"=>true,"created_at"=>date("Y-m-d H:i:s")];
            write_json("coupons.json",$coupons); $ok="Coupon $code created successfully.";
        }
    }
}
?>
<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Coupons - MK Admin</title>
<style>*{box-sizing:border-box}body{margin:0;background:#050509;color:#fff;font-family:Arial;padding:20px}.wrap{max-width:900px;margin:auto}a{color:#00eaff}.box,.coupon{background:#101017;border:1px solid #292933;border-radius:16px;padding:18px;margin-top:15px}input,select{width:100%;padding:13px;margin:7px 0 13px;background:#07070b;color:#fff;border:1px solid #333;border-radius:9px}button{padding:10px 14px;border:0;border-radius:8px;font-weight:bold;cursor:pointer}.create{width:100%;background:#00eaff}.danger{background:#351010;color:#ff7777}.toggle{background:#17334b;color:#fff}.e{background:#351010;color:#ff7777;padding:10px;border-radius:8px}.ok{background:#0b3525;color:#65ffae;padding:10px;border-radius:8px}.row{display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}.code{font-size:22px;font-weight:900;color:#00eaff;letter-spacing:1px}.muted{color:#91a4b5;font-size:13px}</style>
<body><div class="wrap"><a href="dashboard.php">← Dashboard</a><h1>Coupon Codes</h1>
<?php if($e):?><div class="e"><?=h($e)?></div><?php endif;?><?php if($ok):?><div class="ok"><?=h($ok)?></div><?php endif;?>
<div class="box"><h2>Create Coupon</h2><form method="post"><input name="code" placeholder="Example: SAVE10" maxlength="30" required><select name="type"><option value="fixed">Fixed discount (₹)</option><option value="percent">Percentage discount (%)</option></select><input type="number" name="value" min="0.01" step="0.01" placeholder="10 or 20" required><input type="number" name="min_order" min="0" step="0.01" value="0" placeholder="Minimum order (₹), 0 = none"><input type="number" name="max_uses" min="0" step="1" value="0" placeholder="Max uses (0 = unlimited)"><button class="create">CREATE COUPON</button></form></div>
<h2>Existing Coupons</h2>
<?php if(!$coupons):?><div class="coupon muted">No coupons created yet.</div><?php else: foreach(array_reverse($coupons) as $c):?><div class="coupon"><div class="row"><div><div class="code"><?=h($c["code"])?></div><div class="muted"><?=($c["type"]??"fixed")==="percent"?h($c["value"])."% OFF":"₹".h($c["value"])." OFF"?> · Min order: ₹<?=number_format((float)($c["min_order"]??0),2)?> · Used: <?=intval($c["used_count"]??0)?><?php if(intval($c["max_uses"]??0)>0):?> / <?=intval($c["max_uses"])?><?php endif;?> · <?=!empty($c["active"]) ? "Active" : "Inactive"?></div></div><div><form method="post" style="display:inline"><input type="hidden" name="action" value="toggle"><input type="hidden" name="code" value="<?=h($c["code"])?>"><button class="toggle"><?=!empty($c["active"]) ? "Disable" : "Enable"?></button></form> <form method="post" style="display:inline" onsubmit="return confirm('Delete this coupon?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="code" value="<?=h($c["code"])?>"><button class="danger">Delete</button></form></div></div></div><?php endforeach; endif;?></div></body></html>
