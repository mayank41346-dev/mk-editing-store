<?php require "config.php";
if($GOOGLE_CLIENT_ID===""){http_response_code(503);echo "<h2>Google Sign-In setup required</h2><p>Add your Google OAuth Web Client ID in config.php, then configure the redirect URI for this site.</p><p><a href='user-login.php'>Back</a></p>";exit;}
// OAuth endpoint scaffold. A Google OAuth client ID and client secret are required for production use.
$redirect=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.$_SERVER['HTTP_HOST'].'/google-callback.php';
$params=http_build_query(['client_id'=>$GOOGLE_CLIENT_ID,'redirect_uri'=>$redirect,'response_type'=>'code','scope'=>'openid email profile','access_type'=>'online']);
header('Location: https://accounts.google.com/o/oauth2/v2/auth?'.$params);exit;