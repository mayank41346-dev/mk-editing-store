<?php
session_start();
$STORE_NAME="MK Editing Store";
$UPI_ID="9129157962@ibl";
$ADMIN_USERNAME="MAYANK";
$ADMIN_PASSWORD="MAYANK EDITOR #912@91";
$GOOGLE_CLIENT_ID=""; // Add your Google OAuth Web Client ID here to enable Google Sign-In

function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,"UTF-8");}
function read_json($n){$p=__DIR__."/data/".$n;if(!file_exists($p))return []; $d=json_decode(file_get_contents($p),true);return is_array($d)?$d:[];}
function write_json($n,$d){file_put_contents(__DIR__."/data/".$n,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX);}
function admin_required(){if(empty($_SESSION["admin"])){header("Location: /login.php");exit;}}

function user_required(){if(empty($_SESSION["user_email"])){header("Location: /user-login.php");exit;}}
function current_user(){return $_SESSION["user_email"]??null;}
