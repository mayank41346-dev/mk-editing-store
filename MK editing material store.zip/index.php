<?php
require "config.php";
$ps = array_reverse(read_json("products.json"));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MK Editing Store</title>
<style>
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:#02070d;color:#fff;font-family:Arial,Helvetica,sans-serif;overflow-x:hidden}
a{text-decoration:none}
header{position:sticky;top:0;z-index:50;padding:15px 5%;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(0,170,255,.18);background:rgba(2,7,13,.88);backdrop-filter:blur(14px)}
.logo{color:#18a0ff;font-weight:900;letter-spacing:.5px}.admin{color:#c8d4df;font-size:14px}.admin:hover{color:#20a5ff}
.hero{position:relative;padding:75px 5% 55px;overflow:hidden;background:radial-gradient(circle at 15% 50%,rgba(0,119,255,.18),transparent 35%),radial-gradient(circle at 85% 30%,rgba(0,81,255,.12),transparent 35%),#02070d}
.hero-inner{max-width:1150px;margin:auto;display:flex;align-items:center;justify-content:center;gap:75px}
.profile-image-box{position:relative;width:330px;height:330px;flex:0 0 330px}
.profile-image-box:before{content:"";position:absolute;inset:-8px;border-radius:50%;background:linear-gradient(135deg,#00aaff,#006eff,#00d9ff,#006eff);animation:rotateGlow 5s linear infinite;filter:blur(2px)}
.profile-image-box:after{content:"";position:absolute;inset:-18px;border-radius:50%;border:2px solid rgba(0,153,255,.35);box-shadow:0 0 25px #008cff,0 0 60px rgba(0,119,255,.5);animation:pulseGlow 2.5s ease-in-out infinite}
.profile-image{position:relative;z-index:2;width:100%;height:100%;object-fit:cover;object-position:center;border-radius:50%;border:7px solid #03111e;display:block}
.profile-content{max-width:650px}.profile-badge{display:inline-block;padding:9px 18px;margin-bottom:18px;border-radius:30px;font-size:13px;font-weight:700;letter-spacing:1px;color:#fff;background:rgba(0,132,255,.15);border:1px solid rgba(0,153,255,.5);box-shadow:0 0 20px rgba(0,140,255,.15)}
.profile-content h1{margin:0;font-size:clamp(48px,6vw,82px);line-height:1.05;font-weight:800;letter-spacing:-2px}.profile-content h1 span{color:#168cff;text-shadow:0 0 15px rgba(0,136,255,.6),0 0 35px rgba(0,136,255,.25)}
.profile-line{margin-top:15px;font-size:24px;font-weight:600;color:#1598ff;letter-spacing:2px}.profile-bio{margin-top:22px;color:#c5d0dc;font-size:17px;line-height:1.8}
.social-buttons{display:flex;flex-wrap:wrap;gap:15px;margin-top:30px}.social-btn{display:inline-flex;align-items:center;gap:10px;padding:13px 23px;border-radius:30px;color:#fff;font-size:15px;font-weight:700;border:1px solid rgba(255,255,255,.18);transition:transform .25s ease,box-shadow .25s ease}.social-btn:hover{transform:translateY(-5px) scale(1.03)}.social-btn span{font-size:20px}.instagram{background:linear-gradient(135deg,#833ab4,#fd1d1d,#fcb045);box-shadow:0 0 20px rgba(225,48,108,.25)}.youtube{background:#e60000;box-shadow:0 0 20px rgba(255,0,0,.25)}.whatsapp{background:#087f45;box-shadow:0 0 20px rgba(0,255,128,.25)}
.features{max-width:1150px;margin:0 auto 20px;padding:0 5%;display:grid;grid-template-columns:repeat(4,1fr);background:#061321;border:1px solid #12324d;border-radius:18px;overflow:hidden}.feature{padding:22px 18px;border-right:1px solid #17334b}.feature:last-child{border-right:0}.feature b{display:block;font-size:16px}.feature span{display:block;color:#8fa6b9;font-size:12px;margin-top:6px}
.section-head{max-width:1150px;margin:45px auto 15px;padding:0 5%;display:flex;align-items:end;justify-content:space-between;gap:20px}.section-head h2{font-size:36px;margin:0}.section-head h2 span{color:#168cff}.section-head p{color:#8fa6b9;margin:7px 0 0}.view-all{color:#fff;border:1px solid #1598ff;border-radius:24px;padding:10px 18px;white-space:nowrap}
.grid{max-width:1150px;margin:0 auto;padding:20px 5% 45px;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px}.card{background:#07111d;border:1px solid #17334b;border-radius:16px;overflow:hidden;transition:transform .25s ease,border-color .25s ease,box-shadow .25s ease}.card:hover{transform:translateY(-6px);border-color:#1598ff;box-shadow:0 10px 35px rgba(0,119,255,.15)}.card img{width:100%;height:170px;object-fit:cover}.info{padding:16px}.info h3{margin:0 0 8px}.info p{color:#8fa6b9;line-height:1.5;min-height:42px}.price{color:#00c8ff;font-size:20px;font-weight:bold}.buy{display:block;text-align:center;background:#0b8dff;color:#fff;padding:12px;border-radius:9px;font-weight:bold;margin-top:14px}.buy:hover{background:#159dff}
.customer-support{max-width:1150px;margin:10px auto 35px;padding:28px 5%;text-align:center;background:#07111d;border:1px solid #17334b;border-radius:18px}.customer-support h2{color:#18a0ff}.customer-support a{color:#18a0ff}.support-name{font-size:21px;font-weight:bold}
.footer{border-top:1px solid #14304a;background:#030912;padding:35px 5%;text-align:center;color:#8196a8}.footer strong{color:#18a0ff}.footer a{color:#18a0ff;margin:0 7px}
@keyframes rotateGlow{from{transform:rotate(0)}to{transform:rotate(360deg)}}@keyframes pulseGlow{0%,100%{transform:scale(1);opacity:.6}50%{transform:scale(1.05);opacity:1}}
@media(max-width:800px){.hero{padding:60px 18px 50px}.hero-inner{flex-direction:column;gap:40px;text-align:center}.profile-image-box{width:230px;height:230px;flex-basis:230px}.profile-content{width:100%}.profile-badge{font-size:10px;padding:8px 13px}.profile-content h1{font-size:48px;letter-spacing:-1px}.profile-line{font-size:19px}.profile-bio{font-size:14px;line-height:1.7}.social-buttons{justify-content:center}.social-btn{padding:11px 17px;font-size:13px}.features{grid-template-columns:repeat(2,1fr);margin:0 18px}.feature:nth-child(2){border-right:0}.feature:nth-child(-n+2){border-bottom:1px solid #17334b}.section-head{padding:0 18px;align-items:flex-start}.section-head h2{font-size:29px}.grid{padding:20px 18px 35px}.customer-support{margin:10px 18px 30px}.footer{padding:30px 18px}}
@media(max-width:400px){.profile-image-box{width:200px;height:200px;flex-basis:200px}.profile-content h1{font-size:40px}.social-buttons{flex-direction:column;align-items:stretch}.social-btn{justify-content:center}.features{grid-template-columns:1fr}.feature{border-right:0!important;border-bottom:1px solid #17334b}.feature:last-child{border-bottom:0}.section-head{flex-direction:column}}
</style>
</head>
<body>
<header>
  <div class="logo">MK EDITING STORE</div>
  <?php if(!empty($_SESSION["user_email"])): ?>
    <span style="color:#aaa">Hi, <?=h($_SESSION["user_name"]??"User")?> · <a class="admin" href="user-logout.php">Logout</a></span>
  <?php else: ?>
    <a class="admin" href="user-login.php">Login / Register</a>
  <?php endif; ?>
</header>

<section class="hero" id="home">
  <div class="hero-inner">
    <div class="profile-image-box">
      <img src="assets/profile.png" alt="Mayank Editor" class="profile-image">
    </div>
    <div class="profile-content">
      <span class="profile-badge">VIDEO EDITOR • CONTENT CREATOR</span>
      <h1>Mayank <span>Editor</span></h1>
      <div class="profile-line">Edit • Create • Inspire</div>
      <p class="profile-bio">Professional Video Editor | Thumbnails | Reels | Shorts<br>Editing Materials &amp; More. Make Your Content Better With Premium Editing Resources.</p>
      <div class="social-buttons">
        <a href="https://instagram.com/royal_editor_mayank" target="_blank" rel="noopener" class="social-btn instagram"><span>◎</span> Instagram</a>
        <a href="https://www.youtube.com/@MKVLOGER-M9" target="_blank" rel="noopener" class="social-btn youtube"><span>▶</span> YouTube</a>
        <a href="https://wa.me/919129157962" target="_blank" rel="noopener" class="social-btn whatsapp"><span>◉</span> WhatsApp</a>
      </div>
    </div>
  </div>
</section>

<section class="features">
  <div class="feature"><b>⚡ Fast Delivery</b><span>Get your files quickly</span></div>
  <div class="feature"><b>🛡 Secure Payment</b><span>Manual verification</span></div>
  <div class="feature"><b>🎧 Support</b><span>Customer support available</span></div>
  <div class="feature"><b>★ Premium Quality</b><span>Editing resources for creators</span></div>
</section>

<div class="section-head" id="products">
  <div><h2>Our <span>Products</span></h2><p>Premium Editing Materials for You</p></div>
  <a class="view-all" href="#products">View All Products →</a>
</div>

<section class="grid">
<?php if(!$ps): ?>
  <div style="grid-column:1/-1;text-align:center;padding:45px;color:#8fa6b9">No products added yet. Admin can add products from the dashboard.</div>
<?php else: ?>
<?php foreach($ps as $p): ?>
  <div class="card">
    <?php if(!empty($p["image"])): ?><img src="<?=h($p["image"])?>" alt="<?=h($p["name"])?>"><?php endif; ?>
    <div class="info"><h3><?=h($p["name"])?></h3><p><?=h($p["description"])?></p><div class="price">₹<?=h($p["price"])?></div><a class="buy" href="checkout.php?id=<?=intval($p["id"])?>">BUY NOW</a></div>
  </div>
<?php endforeach; ?>
<?php endif; ?>
</section>

<section class="customer-support" id="support">
  <h2>Customer Support</h2>
  <p class="support-name">Mayank Editor</p>
  <p><a href="mailto:mayankeditor91@gmail.com">📧 mayankeditor91@gmail.com</a></p>
  <p><a href="https://instagram.com/royal_editor_mayank" target="_blank" rel="noopener">📸 @royal_editor_mayank</a></p>
</section>

<footer class="footer">
  <strong>MK EDITING STORE</strong><br><br>
  <a href="#home">Home</a> · <a href="#products">Products</a> · <a href="user-login.php">Login</a> · <a href="customer-support.php">Support</a>
  <p>© <?=date('Y')?> MK Editing Store. All Rights Reserved.</p>
</footer>
</body>
</html>
